# -*- coding: iso-8859-1 -*-
# this file is automatically created by setup.py
install_purelib = '/usr/lib/python2.7/dist-packages'
install_platlib = '/usr/lib/python2.7/dist-packages'
install_lib = '/usr/lib/python2.7/dist-packages'
install_headers = '/usr/include/python2.7/LinkChecker'
install_scripts = '/usr/bin'
config_dir = '/usr/share/linkchecker'
install_data = '/usr'
name = u'LinkChecker'
version = u'9.4.0'
author = u'Bastian Kleineidam'
author_email = u'bastian.kleineidam@web.de'
maintainer = u'Bastian Kleineidam'
maintainer_email = u'bastian.kleineidam@web.de'
url = u'http://wummel.github.io/linkchecker/'
license = u'GPL'
description = u'check links in web documents or full websites'
long_description = u'LinkChecker\n============\n\n|Build Status|_ |License|_\n\n.. |Build Status| image:: https://travis-ci.org/linkcheck/linkchecker.svg?branch=master\n.. _Build Status: https://travis-ci.org/linkcheck/linkchecker\n.. |License| image:: http://img.shields.io/badge/license-GPL2-d49a6a.svg\n.. _License: http://opensource.org/licenses/GPL-2.0\n\nCheck for broken links in web sites.\n\nFeatures\n---------\n\n- recursive and multithreaded checking and site crawling\n- output in colored or normal text, HTML, SQL, CSV, XML or a sitemap graph in different formats\n- HTTP/1.1, HTTPS, FTP, mailto:, news:, nntp:, Telnet and local file links support\n- restrict link checking with regular expression filters for URLs\n- proxy support\n- username/password authorization for HTTP, FTP and Telnet\n- honors robots.txt exclusion protocol\n- Cookie support\n- HTML5 support\n- a command line and web interface\n- various check plugins available, eg. HTML syntax and antivirus checks.\n\nInstallation\n-------------\nSee doc/install.txt in the source code archive.\nPython 2.7.2 or later is needed. It doesn\'t work with Python 3 yet, see `#40 <https://github.com/linkcheck/linkchecker/pull/40>`_ for details.\n\n``pip install linkchecker`` should NOT be used for now, as it will install the old version of linkchecker. See `#4 <https://github.com/linkcheck/linkchecker/pull/4>`_.\n\nUsage\n------\nExecute ``linkchecker http://www.example.com``.\nFor other options see ``linkchecker --help``.\n\nDocker usage\n-------------\n\nIf you do not want to install any additional libraries/dependencies you can use the Docker image.\n\nExample for external web site check:\n```\ndocker run --rm -it -u $(id -u):$(id -g) linkchecker/linkchecker --verbose https://google.com\n```\n\nLocal HTML file check:\n```\ndocker run --rm -it -u $(id -u):$(id -g) -v "$PWD":/mnt linkchecker/linkchecker --verbose index.html\n```\n'
keywords = ['link', 'url', 'site', 'checking', 'crawling', 'verification', 'validation']
platforms = ['UNKNOWN']
fullname = u'LinkChecker-9.4.0'
contact = u'Bastian Kleineidam'
contact_email = u'bastian.kleineidam@web.de'
release_date = "xx.xx.xxxx"
portable = 0
